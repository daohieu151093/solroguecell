# Trade log template
Entry thesis: 
Risk cap: 
Exit plan: 
External signal: 

Outcome: 
Notes: 
